package You;

import java.io.File;
import java.util.List;
import java.util.Random;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerJoinEvent;
import cn.nukkit.math.Vector3;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;
import cn.nukkit.utils.TextFormat;

public class E extends PluginBase implements Listener{
	public void onEnable(){
		this.getServer().getPluginManager().registerEvents(this, this);
		this.MKDIRFOLDER();
		this.MKDIRCONFIG();
	}
	public void MKDIRFOLDER(){
		File file=new File(this.getDataFolder()+"/XYZ/");
		file.mkdirs();
		File fil=new File(this.getDataFolder()+"/Players/");
		fil.mkdirs();
	}
	public void MKDIRCONFIG(){
		File file=new File(this.getDataFolder(), "config.yml");
		if(!file.exists()){
			Config config=new Config(this.getDataFolder()+"/config.yml", 2);
			List <String> list=null;
			config.set("LIST", list);
			config.save();
		}
	}
	public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
		
		Player player=this.getServer().getPlayer(sender.getName());
		
		if(command.getName().equals("addtp")){
			if(sender.isOp()){
				if(args.length==1){
					Config add=new Config(this.getDataFolder()+"/config.yml", 2);
					List <String> reload=add.getStringList("LIST");
					reload.add(args[0]);
					add.set("LIST", reload);
					add.set("NUMBER", reload.size());
					add.save();
					Config config=new Config(this.getDataFolder()+"/XYZ/"+args[0]+".yml", 2);
					config.set("X", player.getX());
					config.set("Y", player.getY());
					config.set("Z", player.getZ());
					config.save();
					sender.sendMessage(TextFormat.GREEN+"设置成功!");
				}else{
					sender.sendMessage(TextFormat.RED+("请使用正确格式！--/addtp [文件名]"));
				}
			}else{
				sender.sendMessage(TextFormat.RED+"您没有权限添加！");
			}
		}
		
		return true;
	}
	@EventHandler
	public void onJoin(PlayerJoinEvent event){
		Player player=event.getPlayer();
		
		Config config=new Config(this.getDataFolder()+"/config.yml", 2);
		int number=config.getInt("NUMBER");
			if(number!=0){
				Random a=new Random();
				int math=a.nextInt(number);
				for(int i=0;0<number;i++){
					if(math==i){
						List <String> c=config.getStringList("LIST");
						String[] o=new String[c.size()];
						c.toArray(o);
						Config reload=new Config(this.getDataFolder()+"/XYZ/"+o[i]+".yml", 2);
						double x=Double.valueOf(reload.get("X").toString());
						double y=Double.valueOf(reload.get("Y").toString());
						double z=Double.valueOf(reload.get("Z").toString());
						Vector3 pos=new Vector3(x,y,z);
						player.teleport(pos);
						break;
					}
				}
			}
	}
}
