#FNPC
This is a great NPC plugin.Now in Nukkit!<br />
<br />
Type /fnpc help to display help message.<br />
<br />
Donate link:http://pl.zxda.net/plugins/11.html<br />
<br />
Donate version is same to this version,I just packed it.<br />
<br />
This version follow WTFPL License.<br />

#Contact Me
QQ:765569811 or 1943601164<br />
E-Mail:FENGberd@gmail.com<br />
