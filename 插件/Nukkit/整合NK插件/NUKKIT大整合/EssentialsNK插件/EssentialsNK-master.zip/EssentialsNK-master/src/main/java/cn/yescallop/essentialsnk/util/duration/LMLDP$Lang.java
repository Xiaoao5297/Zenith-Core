package cn.yescallop.essentialsnk.util.duration;

import java.time.Duration;

/**
 * Created by Mulan Lin('Snake1999') on 2016/9/16 15:30.
 */
interface LMLDP$Lang {
    boolean identify(String s);

    Duration convert(String s);

}
