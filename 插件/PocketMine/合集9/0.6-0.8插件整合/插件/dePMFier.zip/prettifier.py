import re
def makeBeatiful(string):
    return _formatLines(string.replace("{","{\n").replace("}","}\n").replace(";",";\n"))

def _formatLines(string):
    currentBlock = 0;
    block = 0;
    newstring = ''
    newnewstring = ''
    endline = ''
    currentCase = []
    print("Formatiing cases...")
    for line in string.split("\n"):
        line = line.strip()
        if(line.__contains__("case") and line.__contains__(':')):
            finalstr = ''
            inCase = False
            for s in re.split(r'(\:)', line):
                finalstr+=s
                if(s.__contains__("case")):
                    inCase = True
                if(inCase and s == ':'):
                    inCase = False
                    finalstr+="\n"
                line = finalstr
        newstring+=line+"\n"
    linenum = 0
    lst = newstring.split("\n")
    print("Placing tabs...")
    for line in lst:
        line = line.strip()
        newline = currentBlock*"\t"+line+endline
        if(newline.__contains__('{')):
            currentBlock += 1
        if(newline.__contains__('}')):
            currentBlock -= 1
            newline = currentBlock*"\t"+line+endline
        if(newline.__contains__('case') and line.__contains__(':')):
                newline = currentBlock*"\t"+line+endline
                if(not (lst[linenum+1].__contains__("case") and lst[linenum+1].__contains__(":"))):
                    currentBlock += 1
                currentCase.insert(0,currentBlock)       
        if(newline.__contains__('break') and len(currentCase) > 0 and currentBlock == currentCase[0]):
            currentCase.pop(0)
            currentBlock -= 1
        newnewstring += newline+"\n"
        linenum+=1
    return newnewstring