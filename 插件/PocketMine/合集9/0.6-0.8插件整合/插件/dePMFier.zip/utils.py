import struct,zlib
def readShort(string):
    return struct.unpack(">H", string)[0]
def inflate(data):
    decompress = zlib.decompressobj(
            -zlib.MAX_WBITS
    )
    inflated = decompress.decompress(data)
    inflated += decompress.flush()
    return inflated
def readInt(string):
    return struct.unpack(">L", string)[0]