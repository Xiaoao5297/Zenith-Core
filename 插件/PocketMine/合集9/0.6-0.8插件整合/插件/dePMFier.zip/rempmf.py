from utils import *
from functools import partial
from prettifier import *
import base64,sys
try:
    filename = sys.argv[1]
except IndexError:
    print("Usage: python rempmf.py filename.pmf")
    sys.exit(0)
with open(filename, 'rb+') as file:
    print("Extracting plugin information...")
    file.seek(5)
    extversion = ord(file.read(1))
    name = file.read(readShort(file.read(2))).decode()
    version = file.read(readShort(file.read(2))).decode()
    author = file.read(readShort(file.read(2))).decode()
    if(extversion >= 1):
        apiversion = file.read(readShort(file.read(2))).decode()
    else:
        apiversion = readShort(file.read(2)).decode()
    mainclass = file.read(readShort(file.read(2))).decode()
    identifier = file.read(readShort(file.read(2)))
    extra = ''
    print("Extracting extra information...")
    if(extversion >= 2):
        extraRaw = inflate(file.read(readInt(file.read(4)))).decode().split(';')
        for v in extraRaw:
            v.strip()
            if(v != ""):
                v = base64.b64decode(v)
                k1 = v.find(':')
                extra[v[0:k1]] = v[-(k1+1):]
    else:
         extra = inflate(file.read(readShort(file.read(2)))).decode();
    print("Extracting code...")
    code = ""
    while True:
        data = file.read(4096)
        if(data == b''):
            break
        if(code == ''):
            code = data
        else:
            code+=data
code = inflate(code).decode()
code = makeBeatiful(code)
with open(name+'.php', 'w') as f:
    print("Writing to file...")
    f.write("<?php\n/*\n__PocketMine Plugin__\nname="+name+"\ndescription=noany\nversion"+version+"\nauthor="+author+"\nclass="+mainclass+"\napiversion="+apiversion+"\n*/\n"+code)
print("Done")