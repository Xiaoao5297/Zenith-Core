<?php
/**
 * Created by PhpStorm.
 * User: dhdj
 * Date: 2017/8/17
 * Time: 上午9:15
 */
namespace Atom;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\plugin\PluginBase;
use pocketmine\network\protocol\Info;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase
    implements Listener
{
    //----------------------------------开始和关闭提示------------------------------------
    //-------------------------------------启动------------------------------------------
    public function onLoad()
    {
        $this->getServer()->getLogger()->info("§aAtomTitle正在加载,请确保你的服务器为1.0.5以上版本且为Tess或者GenPro核心!");
    }

    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        if (Info::CURRENT_PROTOCOL < "105") {
            $this->getServer()->getLogger()->info("§c服务器端版本低于1.0.5会导致AtomTitle启动失败!");
        } else {
            @mkdir($this->getDataFolder(), 0777, true);
            $this->config = new Config($this->getDataFolder() . "Atitle.yml", Config::YAML, array(
                    "是否开启" => "是",
                    "第一行文字" => "§6我的世界 §e服务器",
                    "第二行文字" => "§b由PocketMine强力驱动",
                    "聊天框文字" => "§e欢迎进入我的世界服务器,等你很久了"
                )
            );
            $this->getServer()->getLogger()->info("§eAtomTitle§a已成功运行在PHP版本为: §e" . (PHP_VERSION) . "§a的§e" . (PHP_OS) . "§a系统上.");
        }
    }

    public function onDisable()
    {
        $this->getServer()->getLogger()->info("§aAtomTitle已安全卸载!");
    }
    //---------------------------------------结束---------------------------------------
    /**
     * @param CommandSender $sender
     * @param Command $command
     * @param string $label
     * @param array $args
     */
    //--------------------------------通过指令运行----------------------------------------
    //-------------------------------------启动------------------------------------------
    /**
     * @param CommandSender $sender
     * @param Command $command
     * @param string $label
     * @param array $args
     * @return bool
     */
    public function onCommand(CommandSender $sender, Command $command, $label, array $args)
    {
        if (empty($args[0])) {
            $args[0] = '';
        }
        if (empty($args[1])) {
            $args[1] = '';
        }
        if (empty($args[2])) {
            $args[2] = '';
        }
        if (empty($args[3])) {
            $args[3] = '';
        }
        if (empty($args[4])) {
            $args[4] = '';
        }
        if (empty($args[5])) {
            $args[5] = '';
        }
        if (empty($args[6])) {
            $args[6] = '';
        }
        switch ($command) {
            case 'atitle':
                switch ($args[0]) {
                    case '@a':
                        $whosep = 'all';
                        break;
                    case '@p':
                        $whosep = 'self';
                        break;
                    case '':
                        $whosep = 'wrong';
                        break;
                    case 'help':
                        $sender->sendMessage("§b正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                        return true;
                        break;
                }
                //如果是@p的话就给自己发大字显示

                if (isset($whosep)) {
                } else {
                    $whosep = $args[0];
                    //如果是@a就给所有在线玩家
                    //要不然的话就是给玩家名
                }
                if ($whosep == 'wrong') {
                    $sender->sendMessage("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                    $this->getServer()->getLogger()->error("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                    return true;
                } else {
                    switch ($args[1]) {
                        case '':
                            $num1 = 'wrong';
                            break;
                        default:
                            $num1 = $args[1];
                    }
                    if ($num1 == 'wrong') {
                        $sender->sendMessage("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                        $this->getServer()->getLogger()->error("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                        return true;
                    } else {
                        switch ($args[2]) {
                            case '':
                                $num2 = 'wrong';
                                break;
                            default:
                                $num2 = $args[2];
                        }
                        if ($num2 == 'wrong') {
                            $sender->sendMessage("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                            $this->getServer()->getLogger()->error("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                            return true;
                        } else {
                            switch ($args[3]) {
                                case '@':
                                    $num3 = '惊不惊喜,害不害怕,开不开心,dhdj留下的彩蛋就在这里,2017/8/17/8:53-8:54';
                                    break;
                                case '':
                                    $num3 = 'wrong';
                                    break;
                                default:
                                    $num3 = $args[3];
                            }
                            if ($num3 == 'wrong') {
                                $sender->sendMessage("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                                $this->getServer()->getLogger()->error("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                                return true;
                            } else {
                            }
                            //接下来就是蜜汁时间控制了
                            switch ($args[4]) {
                                case '':
                                    $time1 = 'wrong';
                                    break;
                                case is_numeric($args[4]):
                                    $time1 = $args[4];
                                    $time1 = '20' * $time1;
                                    break;
                                default:
                                    $time1 = '20';
                            }
                            switch ($args[5]) {
                                case '':
                                    $time2 = 'wrong';
                                    break;
                                case is_numeric($args[5]):
                                    $time2 = $args[5];
                                    $time2 = '20' * $time2;
                                    break;
                                default:
                                    $time2 = '100';
                            }
                            switch ($args[6]) {
                                case '':
                                    $time3 = 'wrong';
                                    break;
                                case is_numeric($args[6]):
                                    $time3 = $args[6];
                                    $time3 = '20' * $time3;
                                    break;
                                default:
                                    $time3 = '20';
                            }
                            //接下来判断是否三个时间都不是wrong
                            $num1 = str_replace('&', '§', $num1);
                            $num2 = str_replace('&', '§', $num2);
                            $num3 = str_replace('&', '§', $num3);
                            if ($time1 != 'wrong' || $time2 != 'wrong' || $time3 != 'wrong') {
                                $serverName = $this->getServer()->getName();
                                if ($serverName == "Tesseract" OR $serverName == "GenisysPro") {
                                    //延迟一秒发送
                                    sleep(1);
                                    //发消息给玩家
                                    $playerList = [];
                                    if ($whosep == 'all') {
                                        $playerList = Server::getInstance()->getOnlinePlayers();
                                    } elseif ($whosep == 'self') {
                                        $playerList[] = $sender;
                                    } else {
                                        $playerList[] = Server::getInstance()->getPlayer($whosep);
                                    }
                                    if ($num3 != '惊不惊喜,害不害怕,开不开心,dhdj留下的彩蛋就在这里,2017/8/17/8:53-8:54') {
                                        foreach ($playerList as $player) {
                                            $player->sendTitle($num1, $num2, $time1, $time3, $time2);
                                            $player->sendMessage($num3);
                                        }
                                    } else {
                                        foreach ($playerList as $player) {
                                            $player->sendTitle($num1, $num2, $time1, $time3, $time2);
                                        }
                                    }
                                } else {
                                    //延迟一秒发送
                                    sleep(1);
                                    //发消息给玩家
                                    $playerList = [];
                                    if ($whosep == 'all') {
                                        $playerList = Server::getInstance()->getOnlinePlayers();
                                    } elseif ($whosep == 'self') {
                                        $playerList[] = $sender;
                                    } else {
                                        $playerList[] = Server::getInstance()->getPlayer($whosep);
                                    }
                                    if ($num3 != '惊不惊喜,害不害怕,开不开心,dhdj留下的彩蛋就在这里,2017/8/17/8:53-8:54') {
                                        foreach ($playerList as $player) {
                                            $player->addTitle($num1, $num2, $time1, $time3, $time2);
                                            $player->sendMessage($num3);
                                        }
                                    } else {
                                        foreach ($playerList as $player) {
                                            $player->addTitle($num1, $num2, $time1, $time3, $time2);
                                        }
                                    }
                                }
                            } else {
                                $sender->sendMessage("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                                $this->getServer()->getLogger()->error("§c发生严重错误,正确的使用方法是/atitle [玩家名（可为@a,@p）] [标题1] [标题2] [标题3] [淡入时间] [持续时间] [淡出时间]");
                                return true;
                            }
                        }
                    }
                }
                if (isset($num1)) {
                    unset($num1);
                }
                if (isset($num2)) {
                unset($num2);
                }
                if (isset($num3)) {
                unset($num3);
                }
                if (isset($num1)) {
                unset($time1);
                }
                if (isset($time2)) {

                unset($time2);
                    }
                if (isset($time3)) {
                unset($time3);
                                    }
                    return true;
                break;
                }
        }
    //-------------------------------------结束------------------------------------------
    //--------------------------------通过进服执行----------------------------------------
    //-------------------------------------启动------------------------------------------
    public function onPlayerJoin(PlayerJoinEvent $joinMsg){
        if(Info::CURRENT_PROTOCOL>="105"){
            $playerName=$joinMsg->getPlayer()->getName();
            $serverName=$this->getServer()->getName();
            $target=array("&","@");
            $targets=array("§",$playerName);
            $usejoin=str_replace($target,$targets,$this->config->get("是否开启"));
            if($usejoin!='是'){

            }else {
                $one = str_replace($target, $targets, $this->config->get("第一行文字"));
                $two = str_replace($target, $targets, $this->config->get("第二行文字"));
                $three = str_replace($target, $targets, $this->config->get("聊天框文字"));

                if ($serverName == "Tesseract" OR $serverName == "GenisysPro") {
                    sleep(1);
                    $joinMsg->getPlayer()->sendTitle($one, $two, 1, 1, 5);
                    $joinMsg->getPlayer()->sendMessage($three);
                } else {
                    sleep(1);
                    $joinMsg->getPlayer()->addTitle($one, $two, 1, 1, 5);
                    $joinMsg->getPlayer()->sendMessage($three);
                }
                $joinMsg->setJoinMessage(null);
                return true;
            }
        }else{
            $joinMsg->getPlayer()->sendMessage("§c发生了dhdj难以预料的错误");
            return true;
        }
    }
    //-------------------------------------结束------------------------------------------
    }